CASSANDRAJOINS JAVA API
WRITTEN BY FOUNTOURIS ANTONIOS
JUNE 2015

To build the jar files:

-run setclasspath.bat
-run build.bat in src/ 

CassandraJoins.jar is the module for CassandraJoins
CassandraJoins_time_measure is the same module containing time measurements for join operations without creating any new table with the JOIN results on the database.


